# IPLPrediction
Play with your team. Each person predicts the winning team and person with most number of correct predictions win
